<template>
    <div class="personal">
        <article class="HeadPortrait">
            <a href="javascript:void(0)" @click="resigerClick()">{{personalText.Member[personalText.MemId]}}</a>
            <a class="personalA" v-bind:href="personalText.hrefA">
                <figure>
                    <p><img v-bind:src="personalText.imgSrc"/></p>
                    <figcaption>{{personalText.name}}</figcaption>
                </figure>
            </a>
        </article>
        <div class="Income">
            <ul>
                <li><section class="IncomeMarry"><p>本月收入</p><p><span>{{personalText.monthMarry}}</span>元</p></section></li>
                <li><section class="IncomeMarry"><p>累计收入</p><p><span>{{personalText.Cumulative}}</span>元</p></section></li>
                <li><section class="IncomeMarry"><p><a href="#">提现</a>账户余额</p><p><span>{{personalText.balance}}</span>元</p></section></li>
            </ul>
        </div>
    </div>
</template>

<script>
    export default({
         data(){
             return{
                 personalText:{
                     MemId:0,
                     hrefA:'#',
                     imgSrc:require('../../web/images/persone/tx.jpg'),
                     name:'微信名称',
                     Member:['未注册','普通会员','高级会员'],
                     monthMarry:'100,000.00',
                     Cumulative:"999,000.00",
                     balance:'100,000.00'
                 }
             }
         },
         methods:{
             resigerClick(){
                 alert(1);
             }
         }
    })
    let proNav = require('../../web/webmodule/productNav');
    let BoxProm = require('../../web/webmodule/promptBox');
    let NavArr = [
        {NavName:"活动介绍",NavUrl:"../activity.html"},
        {NavName:"热销产品",NavUrl:"../ProductList.html"},
        {NavName:"个人中心",NavUrl:"../personal.html"}
    ];
    proNav.NavName(2,NavArr);
    proNav.NavList();

    let BoxJosn = [
        {BoxName:'取消',BoxUrl:'javascript:void(0)'},
        {BoxName:'立即注册',BoxUrl:'../register.html'}
    ];
    let BoxText = '<p>未注册</p><br/><p>注册后才可以使用此功能</p>';
    BoxProm.BoxName('Verification',BoxText,BoxJosn);
    BoxProm.BoxMethod();

</script>