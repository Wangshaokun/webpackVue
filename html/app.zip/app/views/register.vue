<template id="template-home">
    <div class="Register">
        <div class="RegisterImg"><img src="../../web/images/register/logo.png"/></div>
        <ul>
            <li v-for="(item,index) in items">
                <div class="RegisterName indexDisplay">
                    <p>{{item.TexName}}</p>
                    <p class="indexFiex"><input type="text" :placeholder="item.TexName" value="" v-model="items[index].value" v-bind:data-index="index" v-on:blur="inputBlur()" /> </p>
                </div>
            </li>
            <li>
                <input type="checkbox"/><i v-on:click="checkClick" v-bind:class="{'selected':checkTrue}" ></i> 我已经知晓并认可<a href="#">《太平保宝用户协议》</a>
            </li>
        </ul>
        <div class="RegisterBtn"><a href="javascript:void(0)" v-on:click="RegBtn()">提交</a> </div>
    </div>
</template>

<script>
    export default{
        data(){
            return {
                //inputText:null,
                items: [
                    { TexName: '姓名' },
                    { TexName: '身份证号' }
                ],
                checkTrue:false,
                inputArr:["",""]
               // btnFalse:false
            }
        },
//        created: function(){
//            // 这里是动态生成v-model,这个可以放在网络请求成功里面;
//            let len = 2;
//            for (let i = 0; i < len; i ++) {
//                let item = {value: ''};
//                this.inputArr.push(item);
//            }
//        },
        methods:{
            checkClick:function(){
                this.checkTrue = !this.checkTrue
            },
            inputBlur:function(e){
                let tag = event.target;
                let index = tag.getAttribute('data-index');
                this.inputArr.splice(index,(index+1),this.items[index].value);
                console.log(this.inputArr.length);
            },
            RegBtn:function(){
                if(this.inputArr[0] === "" || this.inputArr[0] === "underfind" || this.inputArr[0] === "null"){
                    console.log("真实姓名不能为空");
                    return
                }
                let Yreg=/^[a-zA-Z]+$/;
                if( !Yreg.test(this.inputArr[0]) ){
                    if( this.inputArr[0].length < 2 ){
                        console.log("你输入的汉字字符不得低于2个");
                        return
                    }
                }
                if(this.inputArr[1] === "" || this.inputArr[1] === "underfind" || this.inputArr[1] === "null"){
                    console.log("真实身份证不能为空");
                    return
                }
                if( !this.inputArr[1] || !/^\d{6}(18|19|20)?\d{2}(0[1-9]|1[12])(0[1-9]|[12]\d|3[01])\d{3}(\d|X)$/i.test(this.inputArr[1]) ){
                    console.log("身份证号格式错误，请重新输入");
                    return
                }
                if(this.checkTrue){
                    console.log("注册成功");
                    window.location = "../../Member.html"
                }else{
                    console.log("是否同意协议");
                    return
                }

                //获取数据
                  let formData = JSON.stringify(this.inputArr);
                  this.$http({
                      method:"POST",
                      url:"http://192.168.20.26:7998/index",
                      data:formData,
                      //headers:{"X-Requested-With": "XMLHttpRequest"},
                      emulateJSON: true
                  }).then((data) => {
                      console.log("data");
                  },(error) => {
                      console.log("error");
                  })
            }
        }
    }
</script>
