<template id="template-home">
    <div class="prowith_mian">
        <div class="prowith_img">
            <img src="../../web/images/product/prolistImg.jpg" alt="产品图"/>
            <div class="proImgBack"></div>
            <div class="proImgText">
                <p>{{proWith_title.title}}</p>
                <p><b>{{proWith_title.describe}}</b>  |  <span>¥{{proWith_title.marry}}起</span></p>
            </div>
        </div>
        <ul class="proCenterNav indexDisplay">
            <li class="indexFiex" v-for="(proNav,index) in proNavs">
                <a href="javascript:void(0)" v-bind:class="{'navColor':proNav.navTrue}" @click="NavClick(index)">{{proNav.navTitle}}</a>
            </li>
        </ul>
        <div class="proContent">
            <div class="ContentProduct" v-bind:class="[proNav.navTrue ? 'Visible' : 'Hidden']" v-for="proNav in proNavs" >proNav.ContentText</div>
        </div>
    </div>
</template>

<script>
    export default{
        data(){
            return{
                proWith_title:{
                    title:"四海八荒旅行意外险",
                    describe:"承诺续保",
                    marry:99
                },
                proNavs:[
                    {
                        navTitle:'产品介绍',
                        ContentText:'<p><img src="../images/img/1.jpg"/></p><p><img src="../images/img/2.jpg"/></p><p><img src="../images/img/3.jpg"/></p><p><img src="../images/img/4.jpg"/></p><p><img src="../images/img/5.jpg"/><p><img src="../images/img/6.jpg"/></p>',
                        navTrue:true
                    },
                    {
                        navTitle:'详细说明',
                        ContentText:'<p>详细说明</p>',
                        navTrue:false
                    },
                ]
            }
        },
        methods:{
            navFor(){
                let thisLen = this.proNavs.length;
                for(let i = 0; i < thisLen; i++){
                    this.proNavs[i].navTrue = false;
                }
            },
            NavClick(index){
                this.navFor();
                this.proNavs[index].navTrue = true;
            }
        }
    }
    let proNav = require('../../web/webmodule/productNav');
    let NavArr = [
        {NavName:"客服",NavUrl:"javascript:void(0)"},
        {NavName:"转发",NavUrl:"javascript:void(0)"},
        {NavName:"购买记录",NavUrl:"../Record.html"},
        {NavName:"保费测算",NavUrl:"../Premium.html"},
        {NavName:"立即购买",NavUrl:"javascript:void(0)"}
    ];
    proNav.NavName(-1,NavArr);
    proNav.NavList();
</script>