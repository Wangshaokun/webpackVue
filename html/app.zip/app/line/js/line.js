$(function(){
    var ansT = formTime(new Date());
    $('.ansTime').html(ansT);
    ajaxNumber();
    LoadInput();
    inputOcclusion();
    var ua = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(ua)) {
        //iphone
        $(".write_box textarea").focus('click', function () {
            NumberFun();
        });

        $('.write_box textarea').blur(function(){
            $(this).val();
            $('.chatTop ,.speak_window').css({marginTop: '0px'});
            //$(".scrollTopTR").removeAttr('ontouchmove');
        });
    }else{
        //Android
        $('.write_box textarea').focus('click',function () {
            Androider();
        });
        $('.write_box textarea').blur(function(){
            $('.speak_box').css({"padding-bottom":"0px"});
            //$('.speak_window').css({"top":"0px"});
        });
    }
    // if(/Android [4-6]/.test(navigator.appVersion)) {
    //     window.addEventListener("resize", function() {
    //         if(document.activeElement.tagName=="INPUT" || document.activeElement.tagName=="TEXTAREA") {
    //             window.setTimeout(function() {
    //                 document.activeElement.scrollIntoViewIfNeeded();
    //             },0);
    //         }
    //     })
    // }
    IpAnd();
    autoWidth();
});

//页面加载数据
function ajaxNumber(){
    $(".scrollTopTR").removeAttr('ontouchmove');
    $.ajax({
        type: "GET",
        url: "http://101.37.20.241:9000/getResponse",
        dataType:"json",
        success: function(data) {
            var str = "";
            var n = 0;
            for( n in data.dataList){
                if(data.dataList[n].head.from == 'app'){
                    str += '<div class="question boxDiv"><div class="heard_img right"><img src="images/weixin.jpg"></div><div class="question_text clear"><time>' + formatDate(new Date(data.dataList[n].head.sendTime)) + '</time><p>' + data.dataList[n].body.content + '</p><i></i></div></div>'
                }else {
                    str += '<div class="answer boxDiv"><div class="heard_img left"><img src="images/dglvyou.jpg"></div><div class="answer_text"><time>' + formatDate(new Date(data.dataList[n].head.sendTime)) + '</time><p>' + data.dataList[n].body.content + '</p><i></i></div></div>'
                }
            }
            $('.speak_box').append(str);
            for_bottom();
        },
        error:function(err){
            console.log('请求失败');
        }
    });
}

//iphone Style
function NumberFun(){
    var winHeight = $(window).height(),
        KayBordHeight = winHeight/1.8,
        speak_boxHeight = $('.speak_box').outerHeight(true),
        boxDivLen = $('.boxDiv').length,
        boxDivHeight = $('.boxDiv').eq(boxDivLen-1).outerHeight(true),
        wenwenFoo = $('.wenwen-footer').outerHeight(true);
    if(speak_boxHeight >winHeight){
        $(".scrollTopTR").removeAttr('ontouchmove');
    }
    if(speak_boxHeight < (winHeight-KayBordHeight)/1.5){
        $('.chatTop').css({"margin-top":KayBordHeight});
        $('.speak_window').css({"margin-top":KayBordHeight});
    }else if(speak_boxHeight > (winHeight-wenwenFoo)){
        $('.chatTop').css({"margin-top":"0px"});
        $('.speak_window').css({"margin-top":"0px"});
    }else{
        $('.speak_window').css({"margin-top":KayBordHeight-boxDivHeight*(boxDivLen-2)});
    }
}

//input hidden
function inputOcclusion(){
    var timer = null;
    $('#inp').on('focus',function () {
        clearInterval(timer);
        var index = 0;
        timer = setInterval(function(){
            if(index > 5){
                $('body').scrollTop(1000000);
                clearInterval(timer);
            }
            index++;
        },50)
    })
}

//Android
function Androider(){
    var winHeight = $(window).height(),
        KayBordHeight = winHeight/2;
        clienHeight = $(document.body)[0].clientHeight;
    //$('body').height(clienHeight);
    //$('.speak_window').css({"top":-KayBordHeight});
   // $('body').
    //$('.speak_box').css({"padding-bottom":KayBordHeight});
    $('.bottomDivHeight').height(clienHeight/2);
    for_bottom()
}

function LoadInput(){
    var inp = document.querySelector('#wenwen-footer textarea');
    inp.onclick = function (ev) {
        setTimeout(function () {
            document.body.scrollTop = document.documentElement.scrollTop = inp.getBoundingClientRect().top + pageYOffset + 5;
        }, 50);
        window.addEventListener('touchmove', fn, false);
    };

    inp.onblur = function () {
        document.querySelector('body').style.height = "auto";
        document.querySelector('body').removeAttribute('style');
        window.removeEventListener('touchmove', fn, false);
    };

    $('.speak_window').on('click',function(){
        $('.write_box textarea').blur();
    });
}

//动画高度
function IpAnd(){
    var answerLen = $('.speak_box .answer').length,
        WHeight = $(window).height(),
        chatTopHeight = $('.chatTop').outerHeight(true),
        wenwenFooterHeight = $('.wenwen-footer').outerHeight(true);
    $('.speak_window').css({'height': WHeight-(wenwenFooterHeight+chatTopHeight),'padding-bottom': wenwenFooterHeight, "padding-top":chatTopHeight});
    if( answerLen > 5 ){
        $(".scrollTop").removeAttr('ontouchmove');
    }
}

//信息请求
function up_say() {
    $('.write_list').remove();
    var text = $('.write_box textarea').val(),
        str = '<div class="question boxDiv">';
    str += '<div class="heard_img right"><img src="images/weixin.jpg"></div>';
    str += '<div class="question_text clear"><time>' + formTime(new Date()) + '</time><p>' + text + '</p><i></i>';
    str += '</div></div>';

    if (text == '') {
        alert('请输入提问！');
        $('.write_box textarea').focus();
    } else {
        $('.speak_box').append(str);
        $('.write_box textarea').val('');
        $('.write_box textarea').focus();
        autoWidth();
        for_bottom();

        setTimeout(function() {
            var ans = '<div class="answer boxDiv"><div class="heard_img left"><img src="images/dglvyou.jpg"></div>';
            ans += '<div class="answer_text" style="max-width:280px"><time>' + formTime(new Date()) + '</time><p>您发送的文字是：' + text + '</p><i></i>';
            ans += '</div></div>';
            $('.speak_box').append(ans);
            for_bottom();
        }, 1000);
         /*var question_textTime = $.trim($(".question_text time").text());*/
        /*提交数据*/
        $.ajax({
            type: "GET",
            url: "http://101.37.20.241:9000/getResponse",
            data: {
                content: text
                // dataTime: question_textTime
            },
            dataType:"json",
            success: function(data) {
                if(data.errCode == 0){
                    console.log('请求成功');
                    var strHtml = "";
                    strHtml += '<div class="answer boxDiv"><div class="heard_img left"><img src="images/dglvyou.jpg"></div><div class="answer_text"><time>' + formTime(new Date(data.dataList[0].head.sendTime)) + '</time><p>' + data.dataList[0].body.content + '</p><i></i></div></div>';
                    $('.speak_box').append(strHtml);
                    for_bottom();
                }else{
                    console.log('请求失败');
                }
            }
        });
    }
}

//滚动条位置
function for_bottom() {
    var ua = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(ua)) {
        NumberFun();
    }else{
        //$('.speak_box').css({"padding-bottom":'0px'});
    }
    var speak_height = $(".speak_box").outerHeight(true);
    $('.speak_box,.speak_window').animate({
        scrollTop: speak_height
    }, 500);
}

function autoWidth() {
    $('.question_text').css('max-width', $('.question').width() - 60);
}

//Time
function formTime(now){
    var seprat = ':';
    var getHoursed = now.getHours() < 10 ? '0' + now.getHours() : now.getHours();
    var getMinutesed = now.getMinutes() < 10 ? '0' + now.getMinutes() : now.getMinutes();
    var getSecondsed = now.getSeconds() < 10 ? '0' + now.getSeconds() : now.getSeconds();
    var currentTime = getHoursed + seprat + getMinutesed + seprat + getSecondsed;
    return currentTime
}

//时间戳转换
function formatDate(now) {
    var seprat = ':';
    var getMonthed = now.getMonth() < 10 ? '0' + (now.getMonth()+1) : now.getMonth()+1;
    var getDated = now.getDate() < 10 ? '0' + now.getDate() : now.getDate();
    var getHoursed = now.getHours() < 10 ? '0' + now.getHours() : now.getHours();
    var getMinutesed = now.getMinutes() < 10 ? '0' + now.getMinutes() : now.getMinutes();
    var getSecondsed = now.getSeconds() < 10 ? '0' + now.getSeconds() : now.getSeconds();
    var currentNow = now.getFullYear() + '年' + getMonthed + '月' + getDated + '日' + getHoursed + seprat + getMinutesed + seprat + getSecondsed;
    return currentNow
}

//触摸取消blur
function fn(ev) {
    var _target = ev.target || ev.srcElement;
    if (_target.nodeName != 'INPUT') {inp.blur();}
    ev.preventDefault()
};