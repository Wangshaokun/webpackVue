/**
 * Created by Administrator on 2017/5/5.
 */

var ua = navigator.userAgent.toLowerCase();
if (/iphone|ipad|ipod/.test(ua)) {
    $('.write_box textarea').blur(function(){
        $(this).val();
        $('.chatTop ,.speak_window').css({marginTop: '0px'});
        $(".scrollTopTR").removeAttr('ontouchmove');
    });
    $(".write_box textarea").focus('click', function () {
        NumberFun();
    });
}

var answerLen = $('.speak_box .answer').length,
    WHeight = $(window).height(),
    chatTopHeight = $('.chatTop').outerHeight(true),
    wenwenFooterHeight = $('.wenwen-footer').outerHeight(true);
$('.speak_window').css({'height': WHeight-wenwenFooterHeight,'padding-bottom': wenwenFooterHeight});
$('.speak_box').css({
    'margin-top': chatTopHeight
});
if( answerLen > 5 ){
    $(".scrollTop").removeAttr('ontouchmove');
}

var inp = document.querySelector('#wenwen-footer textarea');
inp.onclick = function (ev) {
    setTimeout(function () {
        document.body.scrollTop = document.documentElement.scrollTop = inp.getBoundingClientRect().top + pageYOffset + 5;
    }, 50);
    window.addEventListener('touchmove', fn, false);
};


inp.onblur = function () {
    document.querySelector('body').style.height = "auto";
    document.querySelector('body').removeAttribute('style');
    window.removeEventListener('touchmove', fn, false);
};

$('.speak_window').on('click',function(){
    $('.write_box textarea').blur();
})
//

function NumberFun(){
    var winHeight = $(window).height(),
        KayBordHeight = winHeight/1.8,
        speak_boxHeight = $('.speak_box').outerHeight(true),
        boxDivHeight = $('.boxDiv').outerHeight(true),
        boxDivLen = $('.boxDiv').length;
    if(speak_boxHeight > winHeight){
        $(".scrollTopTR").removeAttr('ontouchmove');
    }
    if(speak_boxHeight < winHeight/2.5){
        $('.chatTop').css({"margin-top":KayBordHeight});
        $('.speak_window').css({"margin-top":KayBordHeight});
    }else if(speak_boxHeight > winHeight){
        $('.chatTop').css({"margin-top":"0px"});
        $('.speak_window').css({"margin-top":"0px"});
    }else{
        $('.speak_window').animate({marginTop:KayBordHeight-boxDivHeight*(boxDivLen-2)},350);
    }
}
function up_say() {
    $('.write_list').remove();
    var text = $('.write_box textarea').val(),
        str = '<div class="question boxDiv">';
    str += '<div class="heard_img right"><img src="images/weixin.jpg"></div>';
    str += '<div class="question_text clear"><time>' + getNowFormatDate() + '</time><p>' + text + '</p><i></i>';
    str += '</div></div>';

    if (text == '') {
        alert('请输入提问！');
        $('.write_box textarea').focus();
    } else {
        $('.speak_box').append(str);
        $('.write_box textarea').val('');
        $('.write_box textarea').focus();
        autoWidth();
        for_bottom();

        setTimeout(function() {
            var ans = '<div class="answer boxDiv"><div class="heard_img left"><img src="images/dglvyou.jpg"></div>';
            ans += '<div class="answer_text" style="max-width:280px"><time>' + getNowFormatDate() + '</time><p>您发送的文字是：' + text + '</p><i></i>';
            ans += '</div></div>';
            //$('.speak_box').append(ans);
            for_bottom();
        }, 1000);
        var question_textTime = $.trim($(".question_text time").text());
        /*提交数据*/
        $.ajax({
            type: "GET",
            url: "http://101.37.20.241:9000/getResponse",//http://101.37.20.241:9000/sendTextMsg
            data: {
                content: text
                // dataTime: question_textTime
            },
            dataType:"json",
            success: function(data) {
                if(data.errCode == 0){
                    console.log('请求成功');
                    var strHtml = "";
                    strHtml += '<div class="answer boxDiv"><div class="heard_img left"><img src="images/dglvyou.jpg"></div><div class="answer_text"><time>' + formatDate(new Date(data.dataList[0].head.sendTime)) + '</time><p>' + data.dataList[0].body.content + '</p><i></i></div></div>';
                    $('.speak_box').append(strHtml);
                    for_bottom();
                }else{
                    console.log('请求失败');
                }
            }
        });
    }
}

function getNowFormatDate() {
    var date = new Date();
    var seperator2 = ":";
    var dataHoursed = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
    var dataMinutesed = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
    var dataSecondsed = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();
    var currentdate = dataHoursed + seperator2 + dataMinutesed + seperator2 + dataSecondsed;
    return currentdate;
}

function clickTime() {
    var timeStr = '<div class="oldTime boxDiv">----- 对话结束时是 <span>' + showLeftTime() + '</span> -----</div>';
    $(".speak_box").append(timeStr);
}

function showLeftTime() {
    var now = new Date();
    var sep_ = '-',
        seprat = ':';
    var getMonthed = now.getMonth() < 10 ? '0' + now.getMonth() : now.getMonth();
    var getDated = now.getDate() < 10 ? '0' + now.getDate() : now.getDate();
    var getHoursed = now.getHours() < 10 ? '0' + now.getHours() : now.getHours();
    var getMinutesed = now.getMinutes() < 10 ? '0' + now.getMinutes() : now.getMinutes();
    var getSecondsed = now.getSeconds() < 10 ? '0' + now.getSeconds() : now.getSeconds();
    var currentNow = now.getFullYear() + sep_ + getMonthed + sep_ + getDated + ' ' + getHoursed + seprat + getMinutesed + seprat + getSecondsed;
    for_bottom();
    return currentNow;
}

function for_bottom() {
    var speak_height = $(".speak_box").outerHeight(true);
    $('.speak_box,.speak_window').animate({
        scrollTop: speak_height
    }, 500);
}

function autoWidth() {
    $('.question_text').css('max-width', $('.question').width() - 60);
}
//触摸取消blur
function fn(ev) {
    var _target = ev.target || ev.srcElement;
    if (_target.nodeName != 'INPUT') {inp.blur();}
    ev.preventDefault()
};

function ajaxNumber(){
    $(".scrollTopTR").removeAttr('ontouchmove');
    $.ajax({
        type: "GET",
        url: "http://101.37.20.241:9000/getResponse",
        dataType:"json",
        success: function(data) {
            var str = "";
            var n = 0;
            for( n in data.dataList){
                if(data.dataList[n].head.from == 'app'){
                    str += '<div class="question boxDiv"><div class="heard_img right"><img src="images/weixin.jpg"></div><div class="question_text clear"><time>' + formatDate(new Date(data.dataList[n].head.sendTime)) + '</time><p>' + data.dataList[n].body.content + '</p><i></i></div></div>'
                }else {
                    str += '<div class="answer boxDiv"><div class="heard_img left"><img src="images/dglvyou.jpg"></div><div class="answer_text"><time>' + formatDate(new Date(data.dataList[n].head.sendTime)) + '</time><p>' + data.dataList[n].body.content + '</p><i></i></div></div>'
                }
            }
            $('.speak_box').append(str);
            for_bottom();
        },
        // error:function(err){
        //     console.log('请求失败');
        // }
    });
}
function formatDate(now) {
    console.log(now);
    var seprat = ':';
    var getMonthed = now.getMonth() < 10 ? '0' + now.getMonth() : now.getMonth();
    var getDated = now.getDate() < 10 ? '0' + now.getDate() : now.getDate();
    var getHoursed = now.getHours() < 10 ? '0' + now.getHours() : now.getHours();
    var getMinutesed = now.getMinutes() < 10 ? '0' + now.getMinutes() : now.getMinutes();
    var getSecondsed = now.getSeconds() < 10 ? '0' + now.getSeconds() : now.getSeconds();
    var currentNow = now.getFullYear() + '年' + getMonthed + '月' + getDated + '日' + getHoursed + seprat + getMinutesed + seprat + getSecondsed;
    return currentNow
}
ajaxNumber();
autoWidth();
// if (!/iphone|ipad|ipod/.test(ua)) {
//     var winHeight = $(window).height(),
//         KayBordHeight = winHeight/1.8,
//         speak_boxHeight = $('.speak_box'),
//         boxDivLen = $('.boxDiv').length;
//     alert(boxDivLen);
//     if(speak_boxHeight > winHeight/2.5){
//         alert(1);
//         $('.speak_window').css({"margin-bottom":KayBordHeight});
//     }
// }
