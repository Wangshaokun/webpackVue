/**
 * Created by Administrator on 2017/5/10.
 */
if(window.orientation!=0){
    var obj=document.getElementById('waynay');
    obj.style.display='block';
}

window.onorientationchange=function(){
    var obj=document.getElementById('waynay');

    if(window.orientation==0){
        obj.style.display='none';
    }else
    {
        obj.style.display='block';
    }
};