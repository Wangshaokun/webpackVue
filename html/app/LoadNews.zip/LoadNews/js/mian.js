$(function(){
    var page = 0; //页数
    var size = 10; //展示个数
    $(".newsLoading").dropload({
        scrollArea : window,
        loadDownFn : function(dataVal){
            page++;
            var strHtml = "";
            location.href = "index.html";
            //parent.location.href = "index.html";
            // $.ajax({
            //     type : "GET",
            //     url : "../../LoadNews/json/data.json",
            //     dataType : "json",
            //     success : function(data){
            //         var len = data.length;
            //         if(len > 0){
            //             for(var i = 0; i < len; i++){
            //                 strHtml += '<li><article class="news_article"><section><figure><img src="' + data[i].image+'"/></figure></section><section><p>marry：$<span>' + data[i].marry + '</span><p></section><section><p>' + data[i].timer + '</p></section></article></li>';
            //             }
            //             console.log("123++++++++++++++++++++++++++++++++");
            //             $(".newsLoading ul").append(strHtml);
            //         }else{
            //             console.log("没有数据了");
            //         }
            //         setTimeout(function(){
            //             $(".newsLoading ul").append(strHtml);
            //             dataVal.resetload();
            //         });
            //     },
            //     error:function(){
            //         console.log("数据加载失败");
            //         dataVal.resetload();
            //     }
            // });
        }
    });
})